#include <stdio.h>

int main() {
    int a = getchar();
    int b = 0;
    int c;
    int d;
    if (a>100) {
        d = a/b;
    }
    return 0;
}
#include <stdio.h>

int main() {
    int a = getchar();
    int b = 0;
    int c = (a!=b);
    int d = b/c;
    return 0;
}